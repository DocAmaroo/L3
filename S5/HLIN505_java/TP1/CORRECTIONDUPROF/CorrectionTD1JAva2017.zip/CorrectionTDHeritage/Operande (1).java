package td3.ex3;

public abstract class Operande {
	public abstract float eval();
}
